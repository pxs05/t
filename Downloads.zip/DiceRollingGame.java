/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package lecture3_2782024.lab_2_scd;
import java.util.Random;

public class DiceRollingGame {
  
    public static void printBoard(int[][] board, int x, int y) {
        board[x][y] = 1; 
        for (int[] board1 : board) {
            for (int j = 0; j < board1.length; j++) {
                if (board1[j] == 1) {
                    System.out.print("x ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
        System.out.println(); 
    }
}
