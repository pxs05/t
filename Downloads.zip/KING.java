/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lecture3_2782024.lab_2_scd;

/**
 *
 * @author usman
 */
public class KING {
  public static int[][] B = new int[10][10];  

  
    public static void PrintboardI() {
        for (int i = 0; i < 10; i++)
        {
            
            for (int j = 0; j < 10; j++) 
            {
              if(i==0||j==4||i==9)
              { B[i][j]=1;}
                System.out.print(B[i][j] + " ");  
            }
            System.out.println();  
        }
    }
    
     public static void PrintboardN() {
        for (int i = 0; i < 10; i++)
        {
            
            for (int j = 0; j < 10; j++) 
            {
              if(j==0||j==i||j==9)
              {
              System.out.print("1" + " ");  
               }
              else {
                  System.out.print("0"+" ");
              }
              
            
        }
            System.out.println();  
    }
    
     }
     
      public static void PrintboardG() {
        for (int i = 0; i < 10; i++)
        {
            
            for (int j = 0; j < 10; j++) 
            {
              if(i==0||j==0||i==9||())
              {
              System.out.print("1" + " ");  
               }
              else {
                  System.out.print("0"+" ");
              }
              
            
        }
            System.out.println();  
    }
    
     }
    
}
