package lecture3_2782024.lab_2_scd;

import java.util.Random;

public class Lab_2_SCD {

  
    public static int Add(int a, int b) {
        return a + b;
    }

   
    public static float Add(float a, float b) {
        return a + b;
    }

   
    public static int Add(String a, String b) {
        return Integer.parseInt(a) + Integer.parseInt(b);
    }

   
    public static int Add(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }

    public static int Add(String[] arr) {
        int sum = 0;
        for (String num : arr)
        {
            sum += Integer.parseInt(num);
        }
        return sum;
    }


    public static void main(String[] args) {
        System.out.println("****************QUESTION 1**************");// Example usage
        System.out.println(Lab_2_SCD.Add(1, 2));          
        System.out.println(Lab_2_SCD.Add(1.0f, 2.4f));     
        System.out.println(Lab_2_SCD.Add("1", "2"));       

        int[] intArray = {1, 2, 3};
        System.out.println(Lab_2_SCD.Add(intArray));       

        String[] stringArray = {"1", "2", "3"};
        System.out.println(Lab_2_SCD.Add(stringArray));
          System.out.println("****************QUESTION 2**************");// Example usage
      
        
         double convertedAmount = CurrencyConverter.convert("PKR", 5, "INR");
        System.out.println("Converted Amount: " + convertedAmount + " INR");
        
          System.out.println("****************QUESTION 3**************");// Example usage
          
           int[][] board = new int[10][10];
        Random random = new Random();
        int x = 0; 
        int y = 0; 
        boolean gameRunning = true;

        while (gameRunning) {
          
            DiceRollingGame.printBoard(board, x, y);

         
            int roll = random.nextInt(6) + 1; 
            System.out.println("Number generated: " + roll);

         
            int newPos = x * 10 + y + roll; 
            if (newPos >= 100) { 
                newPos = 99; 
                gameRunning = false; 
            }

           
            x = newPos / 10;
            y = newPos % 10;

          
            board = new int[10][10];
        }

       
        DiceRollingGame.printBoard(board, x, y);
        System.out.println("Game Over!");
      
        KING.PrintboardI();
        System.out.println();
        KING.PrintboardN();
            System.out.println();
        KING.PrintboardG();
        
        
    }
}


