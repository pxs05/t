/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package lecture3_2782024.main;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Enter URLs (comma-separated): ");
        String[] urls = scanner.nextLine().split(",");

        System.out.println("Enter keywords (comma-separated): ");
        String[] keywords = scanner.nextLine().split(",");

     
        for (String url : urls) {

            try {

                Document document = Jsoup.connect(url.trim()).get();


                checkImageTags(document);


                calculateKeywordFrequency(document, keywords);


                calculateTagFrequency(document);

            } catch (IOException e) {
                System.out.println("Error fetching the URL: " + url.trim());
                e.printStackTrace();
            }
        }
    }





    private static void calculateKeywordFrequency(Document document, String[] keywords) {
        String text = document.body().text().toLowerCase();
        Map<String, Integer> keywordFrequency = new HashMap<>();


        for (String keyword : keywords) {
            keywordFrequency.put(keyword.trim().toLowerCase(), 0);
        }


        for (String word : text.split("\\W+")) {
            if (keywordFrequency.containsKey(word)) {
                keywordFrequency.put(word, keywordFrequency.get(word) + 1);
            }
        }

        System.out.println("Keyword Frequency: ");
        for (Map.Entry<String, Integer> entry : keywordFrequency.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    private static void checkImageTags(Document document) {
        Elements images = document.getElementsByTag("img");
        if (images.size() > 5) {
            System.out.println("the page has more than 5 images.");

        }
    }
    private static void calculateTagFrequency(Document document) {
        Elements allElements = document.getAllElements();
        Map<String, Integer> tagFrequency = new HashMap<>();


        for (Element element : allElements) {
            String tagName = element.tagName();
            tagFrequency.put(tagName, tagFrequency.getOrDefault(tagName, 0) + 1);
        }


        List<Map.Entry<String, Integer>> sortedTags = new ArrayList<>(tagFrequency.entrySet());
        sortedTags.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

        System.out.println("Tag Frequency (sorted): ");
        for (Map.Entry<String, Integer> entry : sortedTags) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}