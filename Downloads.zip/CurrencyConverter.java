/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lecture3_2782024.lab_2_scd;

public class CurrencyConverter {

 
    private static final String[] currencies = {"PKR", "Pound", "Dirham", "INR", "BDT", "JPY"};
    private static final double[] values = {236, 0.88, 3.67, 79, 104, 142};

   
    public static double convert(String baseCurrency, double baseCurrencyValue, String targetCurrency) {
        double baseToUSD = 0;
        double targetToUSD = 0;

      
        for (int i = 0; i < currencies.length; i++) {
            if (currencies[i].equalsIgnoreCase(baseCurrency))
            {
                baseToUSD = baseCurrencyValue / values[i];
                break;
            }
        }

       
        for (int i = 0; i < currencies.length; i++) {
            if (currencies[i].equalsIgnoreCase(targetCurrency)) {
                targetToUSD = values[i];
                break;
            }
        }

  
        return baseToUSD * targetToUSD;
    }


}
